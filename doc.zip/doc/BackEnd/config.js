const config = {
    server: '183.83.184.108',
    database: 'documenttrack',
    user: 'sa',
    password: 'rspm@123',
    options: {
        encrypt: false,
        trustServerCertificate: true,
    },
    pool: {
        max: 100, // Adjust based on your load
        min: 10,
        idleTimeoutMillis: 30000
    } 
};

module.exports = config;
