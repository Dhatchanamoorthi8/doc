const express = require("express");

const cors = require("cors");

const server = express();

const multer = require('multer');

const xlsx = require('xlsx');

const fs = require('fs');

const util = require('util');

const { exec } = require('child_process');

const path = require('path');

const upload = multer({ storage: multer.memoryStorage() });

const PORT = process.env.PORT || 5567;

const nodemailer = require("nodemailer");

const dotenv = require('dotenv')

const bcrypt = require('bcryptjs');

dotenv.config()

server.use(cors());

server.use(express.json({ limit: '100mb' }));
server.use(express.urlencoded({ limit: '100mb', extended: true }));



const readFile = util.promisify(fs.readFile);

const writeFile = util.promisify(fs.writeFile);

const printerSharePath = process.env.PRINTER_SHARE_PATH;

const printerDeviceName = process.env.PRINTER_DEVICE_NAME;

console.log(printerSharePath, " ", printerDeviceName);


const db = require('./db');

db.connect().then(() => {
  console.log('Connected to the database');
}).catch(err => {
  console.error('Database connection failed:', err);

  logErrorToFile('Database connection failed:', err)
});



server.get('/', async (req, res) => {
  try {
    res.json('Document Tracker API On Live ')
  } catch (err) {
    console.log(err);
    res.status(500).json('Internal Server Error ')
  }
});


/// login

server.post('/login', async (req, res) => {
  try {
    const { username, password, ipAddress } = req.body;

    const query = `exec dbo.userlogin '${username}'`;

    const response = await db.query(query);

    const user = response.recordset[0];


    const Pagedata = response.recordsets[1]

    if (user.Result === 404) {
      console.log('User not found');
      return res.status(404).json({ error: 'User not found' });
    }

    let loginattemptCount = user.loginattempt

    const isMatch = await bcrypt.compare(password, user.password); // this user password db password check true or false

    if (user.UserStatus.toLowerCase() !== 'sa' && loginattemptCount >= 3) {

      res.status(400).json({ error: 'Your Password is locked, Please wait for Administrative Approval' });

      const status = 'pl'

      await sendPasswordEmail(username, user.email, user.employeename, password, status, user.branchid);

      return

    } else {

      if (!isMatch) {   /// password match check

        loginattemptCount++

        if (user.UserStatus.toLowerCase() !== 'sa') {

          const query = `update UserMainMaster set loginattempt = ${loginattemptCount} where employeecode = '${username}'`
          const response = await db.query(query)

        }

        return res.status(400).json({ error: `Invalid credentials Attempt ${loginattemptCount}` });

      } else {

        const query = `sp_loginhistory '${username}','${user.employeename}','login','${ipAddress}','${'I'}','${user.branchid}'`

        const response = await db.query(query)

        if (response.rowsAffected) {
          const send = { ...user, usercode: username, password }

          const formattedData = Pagedata.reduce((acc, item) => {
            acc[item.Screenid] = item.status;
            return acc;
          }, {});

          res.status(200).json({ send, pagedata: formattedData || null, message: "Login Successfully", navigation: Pagedata || null });

        }

      }
    }



  } catch (err) {

    console.error(err);
    logErrorToFile(err)
  }
})


server.post('/loginhistory', async (req, res) => {
  try {
    const { usercode,
      username,
      status,
      ipAddress,
      mood,
      branchid } = req.body

    const query = `sp_loginhistory '${usercode}','${username}','${status}','${ipAddress}','${mood}','${branchid}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {
    console.error(error);
    logErrorToFile(error)
  }
})


server.post('/changepassword', async (req, res) => {

  try {
    const { usercode, oldpassword, newpassword, confirmpassword } = req.body


    const query = `SELECT ISNULL((SELECT password FROM UserMainMaster WITH (NOLOCK) WHERE employeecode = '${usercode}'), CAST(0 AS int)) AS password`


    const response = await db.query(query)

    const data = response.recordset[0]


    if (data.password === '0') {
      console.log('User code not found');
      return res.status(404).json({ error: 'User code not found' });

    }

    const isMatch = await bcrypt.compare(oldpassword, data.password);

    if (!isMatch) {
      return res.status(400).json({ error: 'Old Password Not Match' });
    }

    if (isMatch) {

      const hashedPassword = await bcrypt.hash(confirmpassword, 10)  /// encrypt password

      const query = `update UserMainMaster set temppassword = '${hashedPassword}',password = '${hashedPassword}',firstlogin = '${0}',expireddate = getdate() where employeecode = '${usercode}'`

      const response = await db.query(query)

      if (response.rowsAffected) {

        res.json({ message: 'Password Changed Successfully' })
      }

    }

  } catch (err) {

    console.error(err);
    logErrorToFile(err)
  }

})


server.post('/ResetPassword', async (req, res) => {
  try {

    const { id, employeecode, employeename, email, branchid } = req.body

    const generatePassword = (length) => {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      let password = '';
      for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return password;
    };

    const temppassword = generatePassword(8);

    const hashedPassword = await bcrypt.hash(temppassword, 10)  /// encrypt password

    const query = `update UserMainMaster set temppassword = '${hashedPassword}',password = '${hashedPassword}',firstlogin = '${1}',expireddate = getdate() where empid =${id}`

    const response = await db.query(query)

    if (response.rowsAffected) {

      res.status(200).send()

      const status = 're'

      await sendPasswordEmail(employeecode, email, employeename, temppassword, status, branchid);
    }


  } catch (error) {

    console.error(error);
    logErrorToFile(error)
  }
})


server.post('/forgotpassword', async (req, res) => {
  try {

    const { usercode, dateofjoin, email } = req.body

    const query = `select COUNT(*)as count from UserMainMaster where employeecode= '${usercode}' and DateofJoining = cast('${dateofjoin}' as date) and 
    email = '${email}'`

    const response = await db.query(query)

    console.log(response.recordset);

    if (response.recordset[0].count === 0) {

      res.status(400).json({ error: 'Please Check The Data' })
    } else {

      const Branchid = await db.query(`SELECT branchid,employeename FROM UserMainMaster WHERE employeecode = '${usercode}'
                      AND DateofJoining = CAST('${dateofjoin}' AS DATE)  AND email = '${email}'`)

      const branchid = Branchid.recordset[0].branchid


      const generatePassword = (length) => {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let password = '';
        for (let i = 0; i < length; i++) {
          password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
      };

      const temppassword = generatePassword(8);

      const hashedPassword = await bcrypt.hash(temppassword, 10)  /// encrypt password

      const query = `update UserMainMaster set temppassword = '${hashedPassword}',password = '${hashedPassword}',firstlogin = '${1}' where employeecode ='${usercode}'`

      const response = await db.query(query)

      if (response.rowsAffected) {

        const status = 're'

        const employeename = Branchid.recordset[0].employeename

        await sendPasswordEmail(usercode, email, employeename, temppassword, status, branchid);

        res.status(200).json({ message: 'Password Forgot Success' })
      }


    }

  } catch (error) {

    console.error(error);
    logErrorToFile(error)
  }
})


server.post('/ExpirePasswordRest', async (req, res) => {
  try {

    const { usercode, oldpassword, newpassword, confirmpassword } = req.body


    const query = `SELECT ISNULL((SELECT password FROM UserMainMaster WITH (NOLOCK) WHERE employeecode = '${usercode}'), CAST(0 AS int)) AS password;`

    const response = await db.query(query)

    const data = response.recordset[0]


    if (data.password === '0') {
      console.log('User code not found');
      return res.status(404).json({ error: 'User code not found' });
    }

    const isMatch = await bcrypt.compare(oldpassword, data.password);

    if (!isMatch) {
      return res.status(400).json({ error: 'Old Password Not Match' });
    }

    if (isMatch) {

      const hashedPassword = await bcrypt.hash(confirmpassword, 10)  /// encrypt password

      const query = `update UserMainMaster set temppassword = '${hashedPassword}',password = '${hashedPassword}',firstlogin = '${0}',expireddate = getdate() where employeecode = '${usercode}'`

      const response = await db.query(query)

      if (response.rowsAffected) {

        res.json({ message: 'Password Reseted Successfully' })
      }

    }


  } catch (error) {

    console.error(error);
    logErrorToFile(error)
  }
})

/// user Role Master start

server.post('/UserroleMaster', async (req, res) => {
  try {

    const { id, userrole, createdby, updateby, branchid, mode } = req.body

    const query = `exec sp_Userrolemaster '${id}','${userrole}','${createdby}','${updateby}','${branchid}','${mode}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (err) {
    console.error(err);
    logErrorToFile(err)
    res.status(500).json('Internal Server Error ')
  }
});


/// user Role Master End


/// user department Master start

server.post('/DepartmentMaster', async (req, res) => {
  try {

    const { id, departmentname, createdby, updateby, branchid, mode } = req.body

    const query = `exec sp_Userdepartmentmaster '${id}','${departmentname}','${createdby}','${updateby}','${branchid}','${mode}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (err) {
    console.error(err);
    logErrorToFile(err)
    res.status(500).json('Internal Server Error ')
  }
});


/// user department Master End

server.post('/UserMainmasterRegister', async (req, res) => {
  try {

    const { id, createdby, updateby, branchid, mode, employeecode, employeename, email, dateofjoin, UserStatus, userrole, department } = req.body;


    const trimString = (value) => {
      return typeof value === 'string' ? value.trim() : value;
    };

    const trimedemployeecode = trimString(employeecode);
    const trimedemployeename = trimString(employeename);
    const trimedemail = trimString(email);


    const generatePassword = (length) => {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      let password = '';
      for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return password;
    };

    const temppassword = generatePassword(8);

    const hashedPassword = await bcrypt.hash(temppassword, 10)  /// encrypt password


    const InsertQuery = `exec sp_UserMainMaster '${id}','${trimedemployeecode}', '${trimedemployeename}', '${trimedemail}', '${hashedPassword}', '${hashedPassword}', 
        '${dateofjoin}', ${UserStatus}, ${userrole}, ${department},${createdby},'${updateby}',${branchid},'${mode}'`;

    console.log(InsertQuery);

    const response = await db.query(InsertQuery)

    console.log(response.rowsAffected);

    if (response.rowsAffected) {

      const status = 'ur'

      await sendPasswordEmail(employeecode, trimedemail, trimedemployeename, temppassword, status, branchid);

      res.status(200).json({ message: 'User registration successful. The password has been sent to your email.' });

    }
    else {
      res.status(500).json('User registration failed.');
    }


  } catch (error) {
    res.status(500).send("An error occurred while processing your request.");
    console.error(error);
    logErrorToFile(error)
  }
})


server.post('/userMainMasterSelect', async (req, res) => {
  try {

    const { id, updateby, branchid, mode } = req.body

    const Query = `exec sp_UserMainMaster '${id}','', '', '', '', '','', '', 0,0,0,'${updateby}',${branchid},'${mode}'`;

    console.log(Query);


    const response = await db.query(Query)

    res.status(200).send(response.recordset);


  } catch (error) {
    console.error(error);
    logErrorToFile(error)
    res.status(500).send("An error occurred while processing your request.");
  }
});


server.post('/userMainMasterUpdate', async (req, res) => {
  try {

    const { updateddby, mode, id, employeecode, employeename, email, dateofjoin, UserStatus, userrole, department } = req.body

    const Query = `exec sp_UserMainMaster '${id}','${employeecode}', '${employeename}', '${email}', '', '','${dateofjoin}', '${UserStatus}','${userrole}',
    '${department}',0,'${updateddby}',0,'${mode}'`;

    console.log(Query);

    const response = await db.query(Query)

    res.status(200).send(response.rowsAffected);


  } catch (error) {
    console.error(error);
    logErrorToFile(error)
    res.status(500).send("An error occurred while processing your request.");
  }
});



async function sendPasswordEmail(employeecode, email, employeename, password, status, branchid) {
  try {

    const response = await db.query(`SELECT * FROM EmailSendContent where status = '${status}'`)

    const maildata = await response.recordset[0]

    const Frommail = await db.query(`select * FROM EmailConfig where branchid = ${branchid}`)

    const frommdaildata = await Frommail.recordset[0]


    let smtpTransport = nodemailer.createTransport({
      service: `${frommdaildata.ServiceName}`,
      host: `${frommdaildata.HostName}`,
      port: `${frommdaildata.PortNo}`,
      secure: false,
      auth: {
        user: `${frommdaildata.frommail}`,
        pass: `${frommdaildata.apppassword}`,
      },
    });

    const emailContent = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Account Created</title>
        <style>
          body { font-family: 'Arial', sans-serif; line-height: 1.6; margin: 0; padding: 0; }
          .container { max-width: 600px; margin: 20px auto; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); }
          .title { color: #333; font-size: 20px; margin-bottom: 20px; }
          .content { font-size: 16px; }
        </style>
      </head>
      <body>
        <div class="container">
          <h2 class="title">${maildata.bodyHead}</h2>
          <p class="content">${maildata.bodyContent1} ${employeename},</p>
          <p class="content">${maildata.bodyContent2}</p>
           
          <p class="content"><strong>${maildata.bodymain1} ${employeecode}</strong></p>
          <p class="content"><strong>${maildata.bodymain2} ${password}</strong></p>


          <p class="content">${maildata.bodyFooter1}</p>
          <p class="content">${maildata.bodyFooter}<br/>Granules</p>
        </div>
      </body>
      </html>
    `;


    await smtpTransport.sendMail({
      from: `${frommdaildata.frommail}`,
      to: email,
      subject: `${maildata.subject}`,
      html: emailContent,
    });

    console.log("Email sent successfully.");
  } catch (error) {
    console.error('Error sending email:', error);
    logErrorToFile('Error sending email:', error)
  }
}




// employeemaster entry 

server.post('/employeemaster', async (req, res) => {

  try {
    const { id, employeecode, employeename, designation, department, remarks, status, createdby, updateby, mood, branchid } = req.body

    const query = `exec sp_employeemaster '${id}','${employeecode}','${employeename}','${designation}',${department},'${remarks}',${status},${createdby},${updateby},'${mood}','${branchid}'`

    console.log(query);

    const response = await db.query(query)

    console.log(response.recordset);

    res.send(response.recordset)

  } catch (error) {

    console.log(error);
    logErrorToFile(error)
  }
})


// User Authentication Pagemaster

// server.post('/pagemaster', async (req, res) => {
//   try {
//     const { pageid, pagename, createby, updateby, mood, branchid } = req.body


//     const query = `exec sp_PageMaster '${pageid}','${pagename}','${createby}','${updateby}','${mood}','${branchid}'`

//     console.log(query);
//     const response = await db.query(query)

//     res.status(200).send(response.recordset)


//   } catch (err) {

//     console.log(err);
//   }
// })


server.post('/RoleMapping', async (req, res) => {
  try {

    const { pageid, roleid, createby, mood, branchid } = req.body

    console.log(pageid, roleid, createby, mood);

    if (pageid !== '') {
      for (const data of pageid) {

        const query = `exec sp_RoleMapping '${data}','${roleid}','${createby}','${mood}','${branchid}'`

        console.log(query);

        const response = await db.query(query)

        console.log(response.recordset)

      }
      res.status(200).json('success Page Assgined')
    }
    else {

      const query = `exec sp_RoleMapping '${pageid}','${roleid}','${createby}','${mood}','${branchid}'`

      console.log(query);

      const response = await db.query(query)

      res.status(200).send(response.recordset)
    }

  } catch (error) {

    console.log(error);
    logErrorToFile(error)
  }
})




// Document locationmaster

server.post('/locationMaster', async (req, res) => {
  try {

    const { id, name, createby, updateby, mood, branchid } = req.body

    const query = `exec dbo.sp_DocumentLocationmaster '${id}' ,'${name}','${createby}','${updateby}','${mood}','${branchid}' `

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (err) {
    console.log(err);
    logErrorToFile(err)
    res.status(500).json('Internal Server Error')
  }
});


// Document type master

server.post('/DocumenttypeMaster', async (req, res) => {
  try {

    const { id, name, createby, updateby, mood, branchid } = req.body

    const query = `exec dbo.sp_Documenttypemaster '${id}' ,'${name}','${createby}','${updateby}','${mood}','${branchid}' `

    console.log(query);


    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (err) {
    console.log(err);
    logErrorToFile(err)
    res.status(500).json('Internal Server Error')
  }
});

// Document Rack Master

server.post('/DocumentRackMaster', async (req, res) => {
  try {

    const { id, name, createby, updateby, mood, branchid } = req.body

    const query = `exec dbo.sp_DocumentRackmaster '${id}' ,'${name}','${createby}','${updateby}','${mood}','${branchid}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (err) {
    console.log(err);
    logErrorToFile(err)
    res.status(500).json('Internal Server Error')
  }
});


// Document Row Master
server.post('/DocumentRowMaster', async (req, res) => {
  try {

    const { id, name, createby, updateby, mood, branchid } = req.body

    const query = `exec dbo.sp_Documentrowmaster '${id}' ,'${name}','${createby}','${updateby}','${mood}','${branchid}' `

    console.log(query);

    const response = await db.query(query)



    res.status(200).send(response.recordset)

  } catch (err) {
    console.log(err);
    logErrorToFile(err)
    res.status(500).json('Internal Server Error')
  }
});


// Document Master History as main Grid

server.post('/DocumentMasterHistory', async (req, res) => {
  try {
    const { id, RFID, DocumentBatchno, DocumentName, Documenttypeid, ManufactureDate, ExpiryDate, DestractionDate, DocStatus,
      DocLocationid, DocRackid, DocRowid, status, createby, updateby, mood, systemip, branchid, files, Remarks
    } = req.body;



    // Generate a unique RFID number if mood is "I"
    const generateRFID = () => {
      const prefix = 'DC0000000000000000';
      const timestamp = new Date().getTime().toString().slice(-6); // Get the last 6 digits of the current timestamp
      return `${prefix}${timestamp}`;
    };

    let RFIDNumber = mood === "I" ? generateRFID() : RFID;

    // Check for RFID uniqueness in the database if mood is "I"

    if (mood === "I") {
      let isUnique = false;
      while (!isUnique) {
        const checkRFIDQuery = `SELECT COUNT(*) as count FROM DocumentMasterHistory WHERE RFID = '${RFIDNumber}'`;
        let checkResponse = await db.query(checkRFIDQuery);
        if (checkResponse.recordset[0].count === 0) {
          isUnique = true;
        } else {
          RFIDNumber = generateRFID();
        }
      }
    }

    // Use the generated RFID number if mood is "I", otherwise use the empty string

    const finalRFID = mood === "I" ? RFIDNumber : RFID;

    const query = `exec dbo.sp_DocumentMasterHistory '${id}', '${finalRFID}', '${DocumentBatchno}', '${DocumentName}',
      '${Documenttypeid}', '${ManufactureDate}', '${ExpiryDate}', '${DestractionDate}', '${DocStatus}',
      '${DocLocationid}', '${DocRackid}', '${DocRowid}','${createby}', '${updateby}','${status}','${systemip}','${mood}','${branchid}','${files}','${Remarks}'`;

    const response = await db.query(query);

    res.status(200).send(response.recordset);

  } catch (err) {
    console.log(err);
    logErrorToFile(err)
    res.status(500).json('Internal Server Error');
  }
});


server.post('/DocumentUploadData', upload.single('file'), async (req, res) => {

  try {
    const file = req.file;

    const { createdby, systemip, branchid } = req.body; // Extract additional fields

    if (!file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }
    const workbook = xlsx.read(file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(worksheet);

    let uploadcount = 0

    const unuploadedData = [];

    const id = ''

    const mood = 'I'

    const status = 'In'

    const DocStatus = 'A'




    for (const row of data) {
      const { DocumentBatchno, DocumentName, Documenttypeid, ManufactureDate, ExpiryDate, DestractionDate, DocLocation, DocRack, DocRow, Remarks } = row;


      const generateRFID = () => {
        const prefix = 'DC0000000000000000';
        const timestamp = new Date().getTime().toString().slice(-6); // Get the last 6 digits of the current timestamp
        return `${prefix}${timestamp}`;
      };

      let RFIDNumber = generateRFID()

      let isUnique = false;

      while (!isUnique) {
        const checkRFIDQuery = `SELECT COUNT(*) as count FROM DocumentMasterHistory WHERE RFID = '${RFIDNumber}'`;
        let checkResponse = await db.query(checkRFIDQuery);
        if (checkResponse.recordset[0].count === 0) {
          isUnique = true;
        } else {
          RFIDNumber = generateRFID();
        }
      }

      const finalRFID = RFIDNumber


      const trimString = (value) => {
        return typeof value === 'string' ? value.trim() : value;
      };

      // Corrected variable names
      const trimmedDocumentBatchno = trimString(DocumentBatchno);
      const trimmedDocumentName = trimString(DocumentName);
      const trimmedDocLocation = trimString(DocLocation);
      const trimmedDocRack = trimString(DocRack);
      const trimmedDocRow = trimString(DocRow);
      const trimmedDocumenttypeid = trimString(Documenttypeid);


      const convertExcelDateToJSDate = (excelSerialDate) => {
        const baseDate = new Date('1900-01-01');
        const millisecondsPerDay = 24 * 60 * 60 * 1000;
        const daysOffset = excelSerialDate - 1;
        const totalMilliseconds = daysOffset * millisecondsPerDay;
        const resultDate = new Date(baseDate.getTime() + totalMilliseconds);
        resultDate.setHours(0, 0, 0, 0);
        return resultDate;
      };


      const originaldateformate = (date) => {
        return convertExcelDateToJSDate(date).toISOString().split('T')[0];
      }


      console.log(ManufactureDate, ExpiryDate, DestractionDate);


      let originalManufactureDate = ManufactureDate && typeof (ManufactureDate) === 'string' ? ManufactureDate : originaldateformate(ManufactureDate)
      let originalExpiryDate = ExpiryDate && typeof (ExpiryDate) === 'string' ? ExpiryDate : originaldateformate(ExpiryDate)
      let originalDestractionDate = DestractionDate && typeof (DestractionDate) === 'string' ? DestractionDate : originaldateformate(DestractionDate)


      const query = `exec sp_Uploaddocument '${trimmedDocumentBatchno}','${trimmedDocLocation}','${trimmedDocRack}','${trimmedDocRow}','${trimmedDocumenttypeid}','${branchid}'`


      const response = await db.query(query)

      const [data] = response.recordset



      if (data.Count === 0 && data.DocLocationid !== 0 && data.DocRackid !== 0 && data.DocRowid !== 0 && data.Documenttypeid !== 0) {

        const query = `exec dbo.sp_DocumentMasterHistory '${id}', '${finalRFID}', '${DocumentBatchno}', '${trimmedDocumentName}', '${data.Documenttypeid}', '${originalManufactureDate}', '${originalExpiryDate}', '${originalDestractionDate}', '${DocStatus}', '${data.DocLocationid}', '${data.DocRackid}', '${data.DocRowid}', '${createdby}','${0}','${status}','${systemip}','${mood}','${branchid}','','${Remarks}'`;

        const response = await db.query(query);

        if (response.rowsAffected[0] !== 0) {

          uploadcount++
        }

      } else {
        unuploadedData.push({
          DocumentBatchno: row.DocumentBatchno, DocumentName: row.DocumentName, Documenttypeid: row.Documenttypeid,
          ManufactureDate: originalManufactureDate, ExpiryDate: originalExpiryDate, DestractionDate: originalDestractionDate, DocLocation: row.DocLocation, DocRack: row.DocRack, DocRow: row.DocRow, Remarks: row.Remarks
        });

      }

    }


    if (unuploadedData.length > 0) {

      const unuploadedWorkbook = xlsx.utils.book_new();
      const unuploadedWorksheet = xlsx.utils.json_to_sheet(unuploadedData);
      xlsx.utils.book_append_sheet(unuploadedWorkbook, unuploadedWorksheet, 'Unuploaded Data');

      const unuploadedFilePath = path.join(__dirname, 'unuploaded_data.xlsx');

      xlsx.writeFile(unuploadedWorkbook, unuploadedFilePath);

      res.status(200).json({
        message: 'Data uploaded with some errors',
        uploadcount,
        unuploadedFilePath: `/download/unuploaded_data.xlsx`,
      });

    } else {
      res.status(200).json({ message: 'Data uploaded successfully', uploadcount });
    }

    //res.status(200).json({ message: 'Data uploaded successfully', uploadcount });
  } catch (err) {
    logErrorToFile(err)
    console.log(err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});



server.post('/UserUploadData', upload.single('file'), async (req, res) => {

  try {
    const file = req.file;

    const { createdby, systemip, branchid } = req.body; // Extract additional fields

    if (!file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const workbook = xlsx.read(file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(worksheet);

    let uploadcount = 0

    const unuploadedData = [];

    const id = ''

    const mood = 'I'

    const UserStatus = 'A'


    for (const row of data) {
      const { Employeecode, Employeename, Email, DateofJoining, Userrole, Departmentname } = row;


      const trimString = (value) => {
        return typeof value === 'string' ? value.trim() : value;
      };

      // Corrected variable names
      const trimmedEmployeecode = trimString(Employeecode);
      const trimmedEmployeename = trimString(Employeename);
      const trimmedEmail = trimString(Email);
      const trimmedUserrole = trimString(Userrole);
      const trimmedDepartmentname = trimString(Departmentname);


      const convertExcelDateToJSDate = (excelSerialDate) => {
        const baseDate = new Date('1900-01-01');
        const millisecondsPerDay = 24 * 60 * 60 * 1000;
        const daysOffset = excelSerialDate - 1;
        const totalMilliseconds = daysOffset * millisecondsPerDay;
        const resultDate = new Date(baseDate.getTime() + totalMilliseconds);
        resultDate.setHours(0, 0, 0, 0);
        return resultDate;
      };


      const originaldateformate = (date) => {
        return convertExcelDateToJSDate(date).toISOString().split('T')[0];
      }


      let originalDateofJoining = DateofJoining && DateofJoining !== undefined ? originaldateformate(DateofJoining) : undefined



      const query = `exec sp_UploadUser '${trimmedEmployeecode}','${trimmedEmployeename}','${trimmedEmail}','${trimmedUserrole}','${trimmedDepartmentname}','${branchid}'`


      const response = await db.query(query)

      const [data] = response.recordset


      console.log(data);


      if (data.Count === 0 && data.useroleid !== 0 && data.Departmentid !== 0) {



        const generatePassword = (length) => {
          const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
          let password = '';
          for (let i = 0; i < length; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
          }
          return password;
        };

        const temppassword = generatePassword(8);

        const hashedPassword = await bcrypt.hash(temppassword, 10)  /// encrypt password


        const InsertQuery = `exec sp_UserMainMaster '${id}','${trimmedEmployeecode}', '${trimmedEmployeename}', '${trimmedEmail}', '${hashedPassword}', '${hashedPassword}', 
            '${originalDateofJoining}', ${UserStatus}, ${data.useroleid}, ${data.Departmentid},${createdby},'',${branchid},'${mood}'`;

        const response = await db.query(InsertQuery)


        if (response.rowsAffected[0] !== 0) {
          uploadcount++
          const status = 'ur'
          await sendPasswordEmail(trimmedEmployeecode, trimmedEmail, trimmedEmployeename, temppassword, status, branchid);
        }

      } else {
        unuploadedData.push({
          Employeecode: row.Employeecode, Employeename: row.Employeename, Email: row.Email,
          DateofJoining: originalDateofJoining, Userrole: row.Userrole, Departmentname: row.Departmentname
        });

      }

    }


    if (unuploadedData.length > 0) {

      const unuploadedWorkbook = xlsx.utils.book_new();
      const unuploadedWorksheet = xlsx.utils.json_to_sheet(unuploadedData);
      xlsx.utils.book_append_sheet(unuploadedWorkbook, unuploadedWorksheet, 'Unuploaded User Data');

      const unuploadedFilePath = path.join(__dirname, 'unuploaded_User_data.xlsx');

      xlsx.writeFile(unuploadedWorkbook, unuploadedFilePath);

      res.status(200).json({
        message: 'Data uploaded with some errors',
        uploadcount,
        unuploadedFilePath: `/download/unuploaded_User_data.xlsx`,
      });

    } else {
      res.status(200).json({ message: 'Data uploaded successfully', uploadcount });
    }



    //res.status(200).json({ message: 'Data uploaded successfully', uploadcount });
  } catch (err) {
    logErrorToFile(err)
    console.log(err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});



server.get('/download/:filename', (req, res) => {
  const filePath = path.join(__dirname, req.params.filename);
  res.download(filePath, (err) => {
    if (err) {
      console.log('Error downloading file:', err);
      res.status(500).json({ message: 'Error downloading file' });
    } else {
      fs.unlinkSync(filePath); // Clean up the file after download
    }

  });
});



server.get('/user/ip', (req, res) => {
  const ipAddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || (req.connection.socket ? req.connection.socket.remoteAddress : null);

  console.log(ipAddress);
  res.json({ ip: ipAddress });
});





// Label Printing Start

server.post('/lableprint', async (req, res) => {
  try {
    const selectedRows = req.body; // Array of RFIDs from the frontend


    const originalPrn = await readFile('PrnFile.prn', 'utf8');

    const printRFID = async (DocumentBatchno, DocumentName, DocLocationName, DestractionDate, RFID, printedby, systemip, status, branchid) => {
      try {

        // Split the string
        const DocNamepart1 = DocumentName.trim().substring(0, 40) || '';
        const DocNamepart2 = DocumentName.trim().substring(40) || '';


        let modifiedPrn = originalPrn.replace('STRDocNo', DocumentBatchno);
        modifiedPrn = modifiedPrn.replace('STRDocName1', DocNamepart1);
        modifiedPrn = modifiedPrn.replace('STRDocName', DocNamepart2);
        modifiedPrn = modifiedPrn.replace('STRDocLocation1', DocLocationName);
        modifiedPrn = modifiedPrn.replace('STRDocLocation', DocLocationName);
        modifiedPrn = modifiedPrn.replace('STRDsDate', DestractionDate);
        modifiedPrn = modifiedPrn.replace('STRRFID1', RFID);
        modifiedPrn = modifiedPrn.replace('STRRFID', RFID);

        await writeFile('PrnFile.prn', modifiedPrn);

        const commands = `copy "D:\\RSPM\\React Application\\Document-tracking_updated_v1\\backend\\PrnFile.prn" "\\\\DESKTOP-062Q6KU\\Zebra ZD621R (300 dpi) - ZPL"`;

        const command = `copy "${printerSharePath}" "${printerDeviceName}"`


        // Execute the command to print the .prn file
        exec(command, (error, stdout, stderr) => {
          console.log("call printing");
          if (error) {
            console.error(`Error executing batch file: ${error.message}`);
            logErrorToFile(`Error executing batch file: ${error.message}`)
            notifyPrintingFailure(DocumentBatchno, DocumentName, DocLocationName, DestractionDate, RFID, error);
            return;
          }
          if (stderr) {
            console.error(`Batch file stderr: ${stderr}`);
            logErrorToFile(`Batch file stderr: ${stderr}`)
            notifyPrintingFailure(DocumentBatchno, DocumentName, DocLocationName, DestractionDate, RFID, new Error(stderr));
            return;
          }
          console.log(`Batch file stdout: ${stdout}`);
          // Notify printing completion
          notifyPrintingComplete(DocumentBatchno, DocumentName, DocLocationName, DestractionDate, RFID, printedby, systemip, status, branchid);
        });
      } catch (error) {
        console.error(`Error processing RFID ${RFID}:`, error);
        logErrorToFile(`Error processing RFID ${RFID}:`, error)
        // Notify printing failure
        notifyPrintingFailure(DocumentBatchno, DocumentName, DocLocationName, DestractionDate, RFID, error);
      }
    };

    // Function to notify printing completion
    const notifyPrintingComplete = async (DocumentBatchno, DocumentName, DocLocationName, DestractionDate, RFID, printedby, systemip, status, branchid) => {

      const DocNamepart1 = DocumentName.trim().substring(0, 30);
      const DocNamepart2 = DocumentName.trim().substring(30);

      let modifiedPrn = originalPrn.replace(DocumentBatchno, 'STRDocNo');
      modifiedPrn = modifiedPrn.replace(DocNamepart1, 'STRDocName1');
      modifiedPrn = modifiedPrn.replace(DocNamepart2, 'STRDocName');
      modifiedPrn = modifiedPrn.replace(DocLocationName, 'STRDocLocation1');
      modifiedPrn = modifiedPrn.replace(DocLocationName, 'STRDocLocation');
      modifiedPrn = modifiedPrn.replace(DestractionDate, 'STRDsDate');
      modifiedPrn = modifiedPrn.replace(RFID, 'STRRFID1');
      modifiedPrn = modifiedPrn.replace(RFID, 'STRRFID');

      await writeFile('PrnFile.prn', modifiedPrn);

      const response = await db.query(`exec sp_labelprinting '${RFID}','${DocumentBatchno}','${printedby}','${systemip}','${status}','${branchid}'`)

      console.log(`exec sp_labelprinting '${RFID}','${DocumentBatchno}','${printedby}','${systemip}','${status}'`);

      console.log(response.rowsAffected);

      console.log(`RFID ${RFID} printed successfully`);

    };

    // Function to notify printing failure
    const notifyPrintingFailure = async (DocumentBatchno, DocumentName, DocLocationName, DestractionDate, RFID, error) => {

      const DocNamepart1 = DocumentName.trim().substring(0, 30);
      const DocNamepart2 = DocumentName.trim().substring(30);

      let modifiedPrn = originalPrn.replace(DocumentBatchno, 'STRDocNo');
      modifiedPrn = modifiedPrn.replace(DocNamepart1, 'STRDocName1');
      modifiedPrn = modifiedPrn.replace(DocNamepart2, 'STRDocName');
      modifiedPrn = modifiedPrn.replace(DocLocationName, 'STRDocLocation1');
      modifiedPrn = modifiedPrn.replace(DocLocationName, 'STRDocLocation');
      modifiedPrn = modifiedPrn.replace(DestractionDate, 'STRDsDate');
      modifiedPrn = modifiedPrn.replace(RFID, 'STRRFID1');
      modifiedPrn = modifiedPrn.replace(RFID, 'STRRFID');


      await writeFile('PrnFile.prn', modifiedPrn);

      logErrorToFile(`Error printing RFID ${RFID}:`, error)


      console.error(`Error printing RFID ${RFID}:`, error);
      // Here you can emit an event, update a database, or perform any other action to handle printing failure.
    };

    selectedRows.forEach((data, index) => {
      setTimeout(() => {
        printRFID(data.DocumentBatchno, data.DocumentName, data.DocLocationName,
          data.DestractionDate, data.RFID, data.printedby, data.systemip, data.status,
          data.branchid);
      }, index * 2000); // 2-second delay for each RFID
    });

    await res.status(200).json({ message: 'Printed Successfully' }); // Send a response back to the frontend

  } catch (error) {
    logErrorToFile(error)
    console.log(error);
    res.status(500); // Send an error response
  }
});


server.post('/Fetch_labelprint_Data', async (req, res) => {
  try {

    const { status, branchid } = req.body

    const query = `exec sp_labelprinting '','','','','${status}','${branchid}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})

// Label Printing End

// Inward Outward Process  start

server.get('/inwardoutwardProcess', async (req, res) => {

  try {

    const { rfid, batchno, branchid } = req.query

    console.log(rfid, batchno);

    const query = `exec sp_inwardoutwardProcess '','${rfid}','${batchno}','','','','','','','','','','','','','','','S','${branchid}'`

    console.log(query);

    const response = await db.query(query)

    if (response.recordset) {

      res.send(response.recordset)
    }

  } catch (err) {

    logErrorToFile(err)
    console.log(err);
  }
})


server.post('/inwardoutwardProcess', async (req, res) => {
  try {
    const { id,
      RFID,
      DocumentBatchno,
      DocumentName,
      Documenttypeid,
      ManufactureDate,
      ExpiryDate,
      DestractionDate,
      DocLocationid,
      DocRackid,
      DocRowid,
      EmployeeName,
      Remarks,
      inoutStatus,
      createby,
      updateby,
      systemip,
      mood,
      branchid } = req.body

    const query = `exec sp_inwardoutwardProcess ${id},'${RFID}','${DocumentBatchno}','${DocumentName}',${Documenttypeid},
    '${ManufactureDate}','${ExpiryDate}','${DestractionDate}',${DocLocationid},${DocRackid},
    ${DocRowid},${createby},${updateby},'${inoutStatus}','${systemip}',${EmployeeName},'${Remarks}','${mood}','${branchid}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)


  } catch (err) {

    logErrorToFile(err)
    console.log(err);
  }
})

/// inward Outward Process end



//// Aduit trail

server.post('/audittrail', async (req, res) => {
  try {

    const { id, mode, branchid, SearchMode } = req.body

    const query = `exec sp_AudiTrail '${id}','${mode}','${branchid}','${SearchMode}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordsets)


  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


/// doc destruction

server.post('/docdestruction', async (req, res) => {
  try {

    const { id, branchid, destructedby, mode } = req.body

    const query = `exec sp_Docdestruct '${id}','${branchid}','${destructedby}','${mode}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


server.put('/docdestruction', async (req, res) => {
  try {

    const selectedRow = req.body

    let count = 0

    for (const data of selectedRow) {

      const query = `exec sp_Docdestruct '${data.id}',0,'${data.destructedby}','${data.mode}'`

      const response = await db.query(query)

      if (response.rowsAffected) {
        count++
      }
    }
    res.status(200).json({ count })
  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


//// Dashborad Notification 

server.post('/Notification', async (req, res) => {
  try {

    const { id, mood, branchid } = req.body

    const query = `exec dbo.sp_Notification '${id}','${mood}','${branchid}'`

    const response = await db.query(query)

    const count = response.recordsets[0][0].loginAttemptCount

    const PasswordAlertData = response.recordsets[1]

    res.status(200).json({ count, PasswordAlertData })

  } catch (error) {
    logErrorToFile(error)
    console.log(error);
  }
})


/// Dashboard Count

server.post('/DashboradDatas', async (req, res) => {
  try {

    const { branchid } = req.query

    const query = `exec sp_DashboardCount '${branchid}'`

    const response = await db.query(query)

    const Topcard = response.recordsets[0][0]

    const firstCardChart = response.recordsets[1][0]

    const SecondCardChart = response.recordsets[2][0]

    const ThirdCardChart = response.recordsets[3][0]

    const FourthCardChart = response.recordsets[4][0]

    const AuthorizedgridData = response.recordsets[5]

    const UnAuthorizedgridData = response.recordsets[6]

    const UnAuthorizedChartData = response.recordsets[7][0]

    const InOutTranscationGriddata = response.recordsets[8]



    res.status(200).json({ Topcard, firstCardChart, SecondCardChart, ThirdCardChart, FourthCardChart, AuthorizedgridData, UnAuthorizedgridData, UnAuthorizedChartData, InOutTranscationGriddata })

  } catch (error) {
    logErrorToFile(error)
    console.log(error);
  }
})



// BRANCHMASTER 

server.post('/BranchMaster', async (req, res) => {
  try {

    const { id, branchName, createdby, updateby, mood } = req.body

    const quary = `exec sp_BranchMaster '${id}','${branchName}','${createdby}','${updateby}','${mood}'`

    const response = await db.query(quary)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


/// Settings

server.post('/emailconfigsettings', async (req, res) => {
  try {

    const { id, frommail, apppassword, ServiceName, HostName, PortNumber, createdby, updateby, branchid, mode } = req.body

    const query = `exec SP_EMAILCONFIG '${id}','${frommail}','${apppassword}','${ServiceName}','${HostName}','${PortNumber}','${createdby}','${updateby}','${branchid}','${mode}'`


    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


server.post('/othersetting', async (req, res) => {
  try {

    const { id, passwordexpireday, autologouttime, createdby, branchid, mode } = req.body

    const query = `EXEC SP_GeneralSetting '${id}','${passwordexpireday}','${autologouttime}','${createdby}','${branchid}','${mode}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})

/// Report Data

server.post('/InwardOutWardReport', async (req, res) => {
  try {

    const { fromDate, toDate, status, mode, branchid, DocStatus } = req.body


    const query = `exec sp_InwardOutwardReport '${fromDate}','${toDate}','${status}','${mode}','${branchid}','${DocStatus}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


server.post('/DocumentDesctructionReport', async (req, res) => {
  try {

    const { fromDate, toDate, mode, branchid } = req.body



    const query = `exec sp_DestractionDateReport'${fromDate}','${toDate}','${mode}','${branchid}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


server.post('/DocumentMasterHistoryReport', async (req, res) => {
  try {

    const { branchid, fromDate, toDate, mode, DocStatus } = req.body

    const query = `exec sp_DocumentMasterHistoryReport '${fromDate}','${toDate}','${mode}','${branchid}','${DocStatus}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})


server.post('/DocumentWiseAuditReport', async (req, res) => {
  try {

    const { branchid, fromDate, toDate, mode, DocBatchno } = req.body

    const query = `exec DocumentWiseAuditReport '${fromDate}','${toDate}','${mode}','${branchid}','${DocBatchno}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);
  }
})



server.post('/UserWiseAuditReport', async (req, res) => {
  try {

    const { branchid, fromDate, toDate, mode, employeecode } = req.body

    const query = `exec UserWiseAuditReport '${fromDate}','${toDate}','${mode}','${branchid}','${employeecode}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);

  }
})

server.post('/DocumentUnauthorizedReport', async (req, res) => {
  try {

    const { branchid, fromDate, toDate, mode } = req.body

    const query = `exec sp_DocumentUnauthorizedReport '${fromDate}','${toDate}','${mode}','${branchid}'`

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);

  }
})

server.post('/InventoryReport', async (req, res) => {
  try {

    const { branchid, fromDate, toDate, mode } = req.body

    const query = `exec sp_InventoryReport '${fromDate}','${toDate}','${mode}','${branchid}'`

    console.log(query);

    const response = await db.query(query)

    res.status(200).send(response.recordset)

  } catch (error) {

    logErrorToFile(error)
    console.log(error);

  }
})


function logErrorToFile(error) {
  const currentDate = new Date().toISOString();
  const logMessage = `[${currentDate}] ${error}\n`;

  const logFolder = path.join(__dirname, 'log'); // Creates a log folder in the current directory


  // Check if the log folder exists, if not, create it
  if (!fs.existsSync(logFolder)) {
    fs.mkdirSync(logFolder);
  }

  const logFilePath = path.join(logFolder, 'error.txt');

  fs.appendFile(logFilePath, logMessage, (err) => {
    if (err) {
      console.error('Error writing to log file:', err);
    }
  });
}


server.listen(PORT, () => {
  console.log(`Server is connected ${PORT}`);
});
